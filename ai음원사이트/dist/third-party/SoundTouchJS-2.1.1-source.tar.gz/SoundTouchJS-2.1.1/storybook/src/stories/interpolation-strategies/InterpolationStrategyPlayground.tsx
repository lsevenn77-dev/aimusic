import { SoundTouchNode } from '@soundtouchjs/audio-worklet';
import type { RateTransposerInterpolationStrategy } from '@soundtouchjs/core';
import {
  type ChangeEvent,
  type JSX,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import processorModuleUrl from '../../../../packages/audio-worklet/src/processor.ts?url';
import actionableTrack from '../../../../apps/demo/public/bensound-actionable.mp3?url';
import downtownTrack from '../../../../apps/demo/public/bensound-downtown.mp3?url';
import happinessTrack from '../../../../apps/demo/public/bensound-happiness.mp3?url';
import hipjazzTrack from '../../../../apps/demo/public/bensound-hipjazz.mp3?url';
import retrosoulTrack from '../../../../apps/demo/public/bensound-retrosoul.mp3?url';
import interpolationStrategiesInstallerUrl from '../../worklet/interpolation-strategies.installers.ts?url';

interface AudioTrack {
  readonly id: string;
  readonly label: string;
  readonly url: string;
}

interface DatalistTick {
  readonly value: number;
  readonly label: string;
}

interface ParamControl {
  readonly key: string;
  readonly label: string;
  readonly min: number;
  readonly max: number;
  readonly step: number;
  readonly ticks: readonly DatalistTick[];
  readonly display?: (value: number) => string;
}

interface InterpolationStrategyPlaygroundProps {
  readonly title: string;
  readonly description: string;
  readonly explanation: string;
  readonly codeSample: string;
  readonly strategyId: RateTransposerInterpolationStrategy;
  readonly initialParams: Record<string, number>;
  readonly paramControls: readonly ParamControl[];
}

const TRACKS: readonly AudioTrack[] = [
  { id: 'actionable', label: 'Bensound Actionable', url: actionableTrack },
  { id: 'downtown', label: 'Bensound Downtown', url: downtownTrack },
  { id: 'happiness', label: 'Bensound Happiness', url: happinessTrack },
  { id: 'hipjazz', label: 'Bensound Hip Jazz', url: hipjazzTrack },
  { id: 'retrosoul', label: 'Bensound Retro Soul', url: retrosoulTrack },
];

const VOLUME_TICKS: readonly DatalistTick[] = [
  { value: 0, label: '0' },
  { value: 0.5, label: '0.5' },
  { value: 1, label: '1' },
  { value: 1.5, label: '1.5' },
  { value: 2, label: '2' },
  { value: 2.5, label: '2.5' },
  { value: 3, label: '3' },
  { value: 3.5, label: '3.5' },
  { value: 4, label: '4' },
  { value: 4.5, label: '4.5' },
  { value: 5, label: '5' },
  { value: 5.5, label: '5.5' },
  { value: 6, label: '6' },
  { value: 6.5, label: '6.5' },
  { value: 7, label: '7' },
  { value: 7.5, label: '7.5' },
  { value: 8, label: '8' },
  { value: 8.5, label: '8.5' },
  { value: 9, label: '9' },
  { value: 9.5, label: '9.5' },
  { value: 10, label: '10' },
];

const PLAYBACK_RATE_VALUES = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2] as const;

const RATE_TICKS: readonly DatalistTick[] = [
  ...PLAYBACK_RATE_VALUES.map((value) => ({
    value,
    label: String(value),
  })),
];

const PITCH_TICKS: readonly DatalistTick[] = [
  { value: 0.1, label: '0.1' },
  { value: 0.5, label: '0.5' },
  { value: 1, label: '1' },
  { value: 1.5, label: '1.5' },
  { value: 2, label: '2' },
];

const PITCH_SEMITONE_TICKS: readonly DatalistTick[] = [
  { value: -7, label: '-7' },
  { value: -6, label: '-6' },
  { value: -5, label: '-5' },
  { value: -4, label: '-4' },
  { value: -3, label: '-3' },
  { value: -2, label: '-2' },
  { value: -1, label: '-1' },
  { value: 0, label: '0' },
  { value: 1, label: '1' },
  { value: 2, label: '2' },
  { value: 3, label: '3' },
  { value: 4, label: '4' },
  { value: 5, label: '5' },
  { value: 6, label: '6' },
  { value: 7, label: '7' },
];

function formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds - minutes * 60);
  return `${minutes}:${String(remainingSeconds).padStart(2, '0')}`;
}

function displayNumber(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(2);
}

function RangeControl({
  label,
  min,
  max,
  step,
  value,
  onChange,
  ticks,
  listId,
  disabled,
  display,
}: {
  readonly label: string;
  readonly min: number;
  readonly max: number;
  readonly step: number;
  readonly value: number;
  readonly onChange: (value: number) => void;
  readonly ticks: readonly DatalistTick[];
  readonly listId: string;
  readonly disabled: boolean;
  readonly display?: (value: number) => string;
}): JSX.Element {
  return (
    <label style={{ display: 'block' }}>
      {label}: {(display ?? displayNumber)(value)}
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        list={listId}
        onChange={(event) => onChange(Number(event.target.value))}
        disabled={disabled}
        style={{ display: 'block', width: '100%' }}
      />
      <datalist id={listId}>
        {ticks.map((tick) => (
          <option
            key={`${listId}-${tick.value}`}
            value={tick.value}
            label={tick.label}
          />
        ))}
      </datalist>
    </label>
  );
}

export function InterpolationStrategyPlayground({
  title,
  description,
  explanation,
  codeSample,
  strategyId,
  initialParams,
  paramControls,
}: InterpolationStrategyPlaygroundProps): JSX.Element {
  const [selectedTrackId, setSelectedTrackId] = useState(TRACKS[0].id);
  const [volume, setVolume] = useState(1);
  const [rate, setRate] = useState(1);
  const [pitch, setPitch] = useState(1);
  const [pitchSemitones, setPitchSemitones] = useState(0);
  const [loopEnabled, setLoopEnabled] = useState(false);
  const [params, setParams] = useState<Record<string, number>>(initialParams);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState('Idle');

  const audioContextRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const soundTouchNodeRef = useRef<SoundTouchNode | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const startAtContextTimeRef = useRef(0);
  const sourceOffsetRef = useRef(0);
  const rafIdRef = useRef(0);
  const isPlaybackActiveRef = useRef(false);
  const rateRef = useRef(rate);
  const loopEnabledRef = useRef(loopEnabled);
  const durationRef = useRef(duration);

  const selectedTrack = useMemo(
    () => TRACKS.find((track) => track.id === selectedTrackId) ?? TRACKS[0],
    [selectedTrackId],
  );

  const clearSourceNode = useCallback((): void => {
    if (!sourceNodeRef.current) {
      return;
    }

    sourceNodeRef.current.onended = null;
    sourceNodeRef.current.stop();
    sourceNodeRef.current.disconnect();
    sourceNodeRef.current = null;
  }, []);

  const teardownGraph = useCallback(async (): Promise<void> => {
    isPlaybackActiveRef.current = false;
    window.cancelAnimationFrame(rafIdRef.current);
    clearSourceNode();

    if (audioContextRef.current) {
      await audioContextRef.current.close();
    }

    audioContextRef.current = null;
    gainNodeRef.current = null;
    soundTouchNodeRef.current = null;
    audioBufferRef.current = null;
    sourceOffsetRef.current = 0;
    setCurrentTime(0);
    setDuration(0);
    setIsPlaying(false);
  }, [clearSourceNode]);

  const syncNodeParameters = useCallback((): void => {
    if (!soundTouchNodeRef.current || !gainNodeRef.current) {
      return;
    }

    gainNodeRef.current.gain.value = volume;
    soundTouchNodeRef.current.pitch.value = pitch;
    soundTouchNodeRef.current.pitchSemitones.value = pitchSemitones;
    soundTouchNodeRef.current.playbackRate.value = rate;
  }, [pitch, pitchSemitones, rate, volume]);

  const createGraph = useCallback(async (): Promise<void> => {
    const context = new AudioContext();
    await SoundTouchNode.register(context, processorModuleUrl);
    await SoundTouchNode.registerStrategyModule(
      context,
      interpolationStrategiesInstallerUrl,
    );

    const gainNode = context.createGain();
    const soundTouchNode = new SoundTouchNode({
      context,
      interpolationStrategy: { id: strategyId, params },
    });

    soundTouchNode.connect(gainNode);
    gainNode.connect(context.destination);

    audioContextRef.current = context;
    gainNodeRef.current = gainNode;
    soundTouchNodeRef.current = soundTouchNode;
  }, [params, strategyId]);

  const loadTrackBuffer = useCallback(async (): Promise<void> => {
    const response = await fetch(selectedTrack.url);
    const arrayBuffer = await response.arrayBuffer();
    const decodedBuffer =
      await audioContextRef.current!.decodeAudioData(arrayBuffer);

    audioBufferRef.current = decodedBuffer;
    setDuration(decodedBuffer.duration);
    setCurrentTime(0);
    sourceOffsetRef.current = 0;
  }, [selectedTrack.url]);

  const initializeTrack = useCallback(async (): Promise<void> => {
    setIsLoading(true);
    setStatus(`Loading ${selectedTrack.label}...`);

    try {
      await teardownGraph();
      await createGraph();
      await loadTrackBuffer();
      setStatus(`Loaded ${selectedTrack.label}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      setStatus(`Error: ${message}`);
    } finally {
      setIsLoading(false);
    }
  }, [createGraph, loadTrackBuffer, selectedTrack.label, teardownGraph]);

  const tick = useCallback((): void => {
    if (!isPlaybackActiveRef.current) {
      return;
    }

    const context = audioContextRef.current;
    if (!context) {
      return;
    }

    const elapsed =
      sourceOffsetRef.current +
      (context.currentTime - startAtContextTimeRef.current) * rateRef.current;

    const nextTime =
      loopEnabledRef.current && durationRef.current > 0
        ? elapsed % durationRef.current
        : Math.min(elapsed, durationRef.current);
    setCurrentTime(nextTime);

    if (!loopEnabledRef.current && elapsed >= durationRef.current) {
      isPlaybackActiveRef.current = false;
      setIsPlaying(false);
      setStatus('Playback complete');
      return;
    }

    rafIdRef.current = window.requestAnimationFrame(tick);
  }, []);

  const beginPlaybackFromOffset = useCallback(
    async (offset: number): Promise<void> => {
      if (
        !audioContextRef.current ||
        !soundTouchNodeRef.current ||
        !audioBufferRef.current
      ) {
        return;
      }

      clearSourceNode();
      await audioContextRef.current.resume();
      syncNodeParameters();

      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBufferRef.current;
      source.loop = loopEnabledRef.current;
      source.playbackRate.value = rateRef.current;
      source.connect(soundTouchNodeRef.current);
      sourceNodeRef.current = source;
      sourceOffsetRef.current = offset;
      startAtContextTimeRef.current = audioContextRef.current.currentTime;

      source.start(0, offset);
      source.onended = () => {
        if (loopEnabledRef.current) {
          return;
        }
        isPlaybackActiveRef.current = false;
        setIsPlaying(false);
        setStatus('Playback stopped');
      };

      isPlaybackActiveRef.current = true;
      setIsPlaying(true);
      setStatus('Playing');
      rafIdRef.current = window.requestAnimationFrame(tick);
    },
    [clearSourceNode, syncNodeParameters, tick],
  );

  const startPlayback = useCallback(async (): Promise<void> => {
    if (
      !audioContextRef.current ||
      !audioBufferRef.current ||
      !soundTouchNodeRef.current
    ) {
      await initializeTrack();
    }

    const initialOffset = sourceOffsetRef.current;
    await beginPlaybackFromOffset(initialOffset);
  }, [beginPlaybackFromOffset, initializeTrack]);

  const stopPlayback = useCallback((): void => {
    isPlaybackActiveRef.current = false;
    window.cancelAnimationFrame(rafIdRef.current);

    clearSourceNode();

    sourceOffsetRef.current = 0;
    setCurrentTime(0);
    setIsPlaying(false);
    setStatus('Stopped');
  }, [clearSourceNode]);

  const togglePlayback = useCallback(async (): Promise<void> => {
    if (isLoading) {
      return;
    }

    if (isPlaying) {
      stopPlayback();
      return;
    }

    await startPlayback();
  }, [isLoading, isPlaying, startPlayback, stopPlayback]);

  const handleTrackChange = (event: ChangeEvent<HTMLSelectElement>): void => {
    setSelectedTrackId(event.target.value);
  };

  const handleSeek = async (nextTime: number): Promise<void> => {
    if (duration <= 0) {
      return;
    }

    const boundedTime = Math.min(duration, Math.max(0, nextTime));
    sourceOffsetRef.current = boundedTime;
    setCurrentTime(boundedTime);

    if (isPlaying) {
      await beginPlaybackFromOffset(boundedTime);
    }
  };

  const isStrategyParamsDisabled = isLoading || isPlaying;

  useEffect(() => {
    syncNodeParameters();
  }, [syncNodeParameters]);

  useEffect(() => {
    rateRef.current = rate;

    if (sourceNodeRef.current) {
      sourceNodeRef.current.playbackRate.value = rate;
    }
  }, [rate]);

  useEffect(() => {
    loopEnabledRef.current = loopEnabled;
    if (sourceNodeRef.current) {
      sourceNodeRef.current.loop = loopEnabled;
    }
  }, [loopEnabled]);

  useEffect(() => {
    durationRef.current = duration;
  }, [duration]);

  useEffect(() => {
    void initializeTrack();
  }, [initializeTrack]);

  useEffect(() => {
    return () => {
      void teardownGraph();
    };
  }, [teardownGraph]);

  useEffect(() => {
    if (!soundTouchNodeRef.current) {
      return;
    }

    soundTouchNodeRef.current.setInterpolationStrategy({
      id: strategyId,
      params,
    });
    soundTouchNodeRef.current.setInterpolationStrategyParams(params);
  }, [params, strategyId]);

  return (
    <div
      style={{
        maxWidth: 860,
        padding: '1rem',
        fontFamily: 'ui-sans-serif, system-ui, sans-serif',
      }}
    >
      <h3 style={{ marginTop: 0 }}>{title}</h3>
      <p style={{ marginTop: 0, color: '#4b5563' }}>{description}</p>

      <div
        style={{
          display: 'grid',
          gap: '0.75rem',
          gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
        }}
      >
        <label>
          Track
          <select
            value={selectedTrackId}
            onChange={handleTrackChange}
            disabled={isLoading}
            style={{ display: 'block', width: '100%' }}
          >
            {TRACKS.map((track) => (
              <option key={track.id} value={track.id}>
                {track.label}
              </option>
            ))}
          </select>
        </label>

        <RangeControl
          label="Volume"
          min={0}
          max={10}
          step={0.01}
          value={volume}
          onChange={setVolume}
          ticks={VOLUME_TICKS}
          listId="volume-ticks"
          disabled={isLoading}
        />

        <RangeControl
          label="Pitch"
          min={0.1}
          max={2}
          step={0.01}
          value={pitch}
          onChange={setPitch}
          ticks={PITCH_TICKS}
          listId="pitch-ticks"
          disabled={isLoading}
        />

        <RangeControl
          label="Pitch semitones"
          min={-7}
          max={7}
          step={1}
          value={pitchSemitones}
          onChange={setPitchSemitones}
          ticks={PITCH_SEMITONE_TICKS}
          listId="pitch-semitones-ticks"
          disabled={isLoading}
        />

        <RangeControl
          label="Playback Rate"
          min={PLAYBACK_RATE_VALUES[0]}
          max={PLAYBACK_RATE_VALUES[PLAYBACK_RATE_VALUES.length - 1]}
          step={0.25}
          value={rate}
          onChange={setRate}
          ticks={RATE_TICKS}
          listId="rate-ticks"
          disabled={isLoading}
        />

        <label style={{ alignSelf: 'end' }}>
          <input
            type="checkbox"
            checked={loopEnabled}
            onChange={(event) => setLoopEnabled(event.target.checked)}
            disabled={isLoading}
          />{' '}
          Loop playback
        </label>

        <fieldset
          style={{
            border: '1px solid #d1d5db',
            borderRadius: 6,
            gridColumn: 'span 3',
          }}
        >
          <legend>{title} tunable params</legend>
          <div
            style={{
              display: 'grid',
              gap: '0.75rem',
              gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            }}
          >
            {paramControls.map((control) => (
              <RangeControl
                key={control.key}
                label={control.label}
                min={control.min}
                max={control.max}
                step={control.step}
                value={params[control.key] ?? 0}
                onChange={(nextValue) => {
                  setParams((prev) => ({
                    ...prev,
                    [control.key]: nextValue,
                  }));
                }}
                ticks={control.ticks}
                listId={`${strategyId}-${control.key}-ticks`}
                disabled={isStrategyParamsDisabled}
                display={control.display}
              />
            ))}
          </div>
          <p style={{ marginTop: '0.5rem', marginBottom: 0, color: '#6b7280' }}>
            Strategy params are disabled while playback is active.
          </p>
        </fieldset>
      </div>

      <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
        <button type="button" onClick={() => void togglePlayback()} disabled={isLoading}>
          {isLoading ? 'Loading...' : isPlaying ? 'Pause' : 'Play'}
        </button>
      </div>

      <div style={{ marginTop: '0.75rem' }}>
        <input
          type="range"
          min={0}
          max={duration || 0}
          step={0.01}
          value={duration > 0 ? currentTime : 0}
          onChange={(event) => {
            void handleSeek(Number(event.target.value));
          }}
          disabled={duration <= 0 || isLoading}
          style={{ width: '100%' }}
        />
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            marginTop: '0.25rem',
            fontSize: '0.9rem',
          }}
        >
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
      </div>

      <p style={{ marginBottom: 0, marginTop: '0.75rem', color: '#374151' }}>
        {status}
      </p>

      <div style={{ marginTop: '1rem' }}>
        <strong>TypeScript example</strong>
        <pre
          style={{
            marginTop: '0.5rem',
            background: '#f3f4f6',
            padding: '0.75rem',
            borderRadius: 8,
            overflowX: 'auto',
          }}
        >
          <code>{codeSample}</code>
        </pre>
      </div>

      <p style={{ marginTop: '0.75rem', color: '#1f2937' }}>{explanation}</p>
    </div>
  );
}

export type { DatalistTick, ParamControl };